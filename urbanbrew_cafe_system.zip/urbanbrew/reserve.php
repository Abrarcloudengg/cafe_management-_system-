<?php
require_once 'config.php';
require_once 'includes/auth.php';
$pageTitle = 'Reserve a Table';
$errors = []; $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = trim($_POST['customer_name'] ?? '');
    $mobile  = trim($_POST['mobile'] ?? '');
    $guests  = intval($_POST['guests'] ?? 0);
    $date    = $_POST['date'] ?? '';
    $time    = $_POST['time'] ?? '';
    $request = trim($_POST['special_request'] ?? '');

    if (!$name)  $errors[] = 'Name is required.';
    if (!preg_match('/^\+?[\d\s\-]{7,15}$/', $mobile)) $errors[] = 'Valid mobile number required.';
    if ($guests < 1 || $guests > 20) $errors[] = 'Guests must be between 1 and 20.';
    if (!$date || strtotime($date) < strtotime(date('Y-m-d'))) $errors[] = 'Please select a valid future date.';
    if (!$time)  $errors[] = 'Time is required.';

    if (empty($errors)) {
        $db  = getDB();
        $uid = $_SESSION['user_id'] ?? null;
        $stmt = $db->prepare("INSERT INTO reservations (user_id,customer_name,mobile,guests,date,time,special_request) VALUES (?,?,?,?,?,?,?)");
        $stmt->execute([$uid, $name, $mobile, $guests, $date, $time, $request]);
        $success = "Table reserved for $guests guest(s) on " . date('d M Y', strtotime($date)) . " at $time. We'll confirm on $mobile.";
    }
}
?>
<?php require_once 'includes/header.php'; ?>
<div class="page-section">
  <div class="container" style="max-width:620px">
    <div class="card" style="margin-top:1rem">
      <h2 style="font-family:'Playfair Display',serif;font-size:1.9rem;font-weight:700;margin-bottom:.3rem">Reserve a Table</h2>
      <p style="color:var(--medium-roast);margin-bottom:1.5rem">Book your spot at Urban Brew Cafe, Kolhapur.</p>
      <?php foreach ($errors as $e): ?><div class="alert alert-error"><?= sanitize($e) ?></div><?php endforeach; ?>
      <?php if ($success): ?><div class="alert alert-success">✅ <?= sanitize($success) ?></div><?php endif; ?>
      <form method="POST" novalidate>
        <div class="form-row">
          <div class="form-group">
            <label>Your Name</label>
            <input type="text" name="customer_name" value="<?= sanitize($_POST['customer_name'] ?? '') ?>" placeholder="Rahul Sharma" required/>
          </div>
          <div class="form-group">
            <label>Mobile Number</label>
            <input type="tel" name="mobile" value="<?= sanitize($_POST['mobile'] ?? '') ?>" placeholder="+91 XXXXX XXXXX" required/>
          </div>
        </div>
        <div class="form-group">
          <label>Number of Guests</label>
          <select name="guests" required>
            <option value="">Select guests</option>
            <?php for ($i = 1; $i <= 10; $i++): ?>
              <option value="<?= $i ?>" <?= (($_POST['guests'] ?? '') == $i) ? 'selected' : '' ?>><?= $i ?> Person<?= $i > 1 ? 's' : '' ?></option>
            <?php endfor; ?>
          </select>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>Date</label>
            <input type="date" name="date" value="<?= sanitize($_POST['date'] ?? '') ?>" min="<?= date('Y-m-d') ?>" required/>
          </div>
          <div class="form-group">
            <label>Time</label>
            <input type="time" name="time" value="<?= sanitize($_POST['time'] ?? '') ?>" required/>
          </div>
        </div>
        <div class="form-group">
          <label>Special Request <span style="font-weight:400;text-transform:none;letter-spacing:0">(optional)</span></label>
          <textarea name="special_request" placeholder="Allergies, occasion, seating preference..."><?= sanitize($_POST['special_request'] ?? '') ?></textarea>
        </div>
        <button type="submit" class="submit-btn">Confirm Reservation →</button>
      </form>
    </div>
  </div>
</div>
<?php require_once 'includes/footer.php'; ?>
