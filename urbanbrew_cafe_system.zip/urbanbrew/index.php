<?php
require_once 'config.php';
require_once 'includes/auth.php';
$pageTitle = 'Home';

// Fetch recent public feedback
$db = getDB();
$feedbacks = $db->query("SELECT name, rating, comment, created_at FROM feedback ORDER BY created_at DESC LIMIT 4")->fetchAll();
?>
<?php require_once 'includes/header.php'; ?>

<!-- HERO -->
<section class="hero">
  <div class="hero-bg"></div>
  <div class="hero-overlay"></div>
  <div class="hero-content">
    <p class="hero-label">Est. 2015 · Artisan Coffee · Kolhapur</p>
    <h1 class="hero-title">Where Every Cup<br>Tells a <em>Story</em></h1>
    <p class="hero-sub">Handcrafted brews, warm ambiance, and flavors that linger long after the last sip.</p>
    <div class="hero-btns">
      <a href="<?= SITE_URL ?>/order.php" class="btn btn-primary">Order Now</a>
      <a href="<?= SITE_URL ?>/reserve.php" class="btn btn-outline">Book a Table</a>
    </div>
  </div>
</section>

<!-- ABOUT -->
<section id="about" style="background:#fff;padding:5rem 5%">
  <div class="about-grid">
    <div class="about-img-wrap reveal">
      <img src="https://images.unsplash.com/photo-1521017432531-fbd92d768814?w=800&q=80" alt="Cafe Interior" loading="lazy"/>
      <div class="about-badge"><span class="num">10+</span><span class="lbl">Years of Craft</span></div>
    </div>
    <div class="reveal">
      <p class="section-label">Our Story</p>
      <h2 class="section-title">Brewed with Passion,<br>Served with Soul</h2>
      <div class="divider"></div>
      <p class="section-desc">Urban Brew Cafe began as a small corner shop in Kolhapur with one espresso machine and a big dream. Today, we serve thousands of coffee lovers every week — each cup crafted with the same devotion as the very first one.</p>
      <p class="section-desc" style="margin-top:.9rem">We source single-origin beans, partner with local farms, and roast in-house to ensure every sip is an experience worth savoring.</p>
      <div class="stats-row">
        <div class="stat"><div class="num">50K+</div><div class="lbl">Happy Customers</div></div>
        <div class="stat"><div class="num">30+</div><div class="lbl">Menu Items</div></div>
        <div class="stat"><div class="num">12</div><div class="lbl">Master Baristas</div></div>
      </div>
    </div>
  </div>
</section>

<!-- MENU -->
<section id="menu" class="menu-section">
  <div class="text-center reveal" style="margin-bottom:2.5rem">
    <p class="section-label">Our Menu</p>
    <h2 class="section-title">Crafted for Every Craving</h2>
    <div class="divider"></div>
    <p class="section-desc">From bold espresso shots to velvety matcha lattes — something for every mood.</p>
  </div>
  <div class="menu-tabs reveal">
    <button class="tab-btn active" onclick="filterMenu('all',this)">All</button>
    <button class="tab-btn" onclick="filterMenu('coffee',this)">Coffee</button>
    <button class="tab-btn" onclick="filterMenu('cold',this)">Cold Drinks</button>
    <button class="tab-btn" onclick="filterMenu('food',this)">Food</button>
  </div>
  <div class="menu-grid" id="menuGrid"></div>
</section>

<!-- GALLERY -->
<section class="gallery-section">
  <div class="text-center reveal" style="margin-bottom:2.5rem">
    <p class="section-label">Inside Urban Brew</p>
    <h2 class="section-title">A Glimpse of the Vibe</h2>
    <div class="divider"></div>
  </div>
  <div class="gallery-grid reveal">
    <div class="gallery-item"><img src="https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=900&q=80" alt="Cafe" loading="lazy"/></div>
    <div class="gallery-item"><img src="https://images.unsplash.com/photo-1510591509098-f4fdc6d0ff04?w=600&q=80" alt="Espresso" loading="lazy"/></div>
    <div class="gallery-item"><img src="https://images.unsplash.com/photo-1461023058943-07fcbe16d735?w=600&q=80" alt="Latte" loading="lazy"/></div>
    <div class="gallery-item"><img src="https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=600&q=80" alt="Pastry" loading="lazy"/></div>
    <div class="gallery-item"><img src="https://images.unsplash.com/photo-1554118811-1e0d58224f24?w=900&q=80" alt="Seating" loading="lazy"/></div>
  </div>
</section>

<!-- TEAM -->
<section id="team" style="background:#fff;padding:5rem 5%">
  <div class="text-center reveal" style="margin-bottom:2.5rem">
    <p class="section-label">Meet the Team</p>
    <h2 class="section-title">The People Behind the Brew</h2>
    <div class="divider"></div>
  </div>
  <div class="team-grid">
    <div class="team-card reveal">
      <div class="team-avatar">
        <img src="https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&fit=crop" alt="Arjun Patil" loading="lazy" onerror="this.src='https://images.pexels.com/photos/3785079/pexels-photo-3785079.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&fit=crop'"/>
      </div>
      <h4>Arjun Patil</h4><p class="role">Head Barista</p>
    </div>
    <div class="team-card reveal">
      <div class="team-avatar">
        <img src="https://images.pexels.com/photos/3756679/pexels-photo-3756679.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&fit=crop" alt="Priya Deshmukh" loading="lazy" onerror="this.src='https://images.pexels.com/photos/3769021/pexels-photo-3769021.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&fit=crop'"/>
      </div>
      <h4>Priya Deshmukh</h4><p class="role">Pastry Chef</p>
    </div>
    <div class="team-card reveal">
      <div class="team-avatar">
        <img src="https://images.pexels.com/photos/3785079/pexels-photo-3785079.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&fit=crop" alt="Rohan Kulkarni" loading="lazy" onerror="this.src='https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&fit=crop'"/>
      </div>
      <h4>Rohan Kulkarni</h4><p class="role">Cafe Manager</p>
    </div>
    <div class="team-card reveal">
      <div class="team-avatar">
        <img src="https://images.pexels.com/photos/3769021/pexels-photo-3769021.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&fit=crop" alt="Sneha Jadhav" loading="lazy" onerror="this.src='https://images.pexels.com/photos/3756679/pexels-photo-3756679.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&fit=crop'"/>
      </div>
      <h4>Sneha Jadhav</h4><p class="role">Roast Specialist</p>
    </div>
  </div>
</section>

<!-- FEEDBACK SHOWCASE -->
<?php if (!empty($feedbacks)): ?>
<section style="background:var(--cream);padding:5rem 5%">
  <div class="text-center reveal" style="margin-bottom:2rem">
    <p class="section-label">What Our Guests Say</p>
    <h2 class="section-title">Real Words, Real Love</h2>
    <div class="divider"></div>
  </div>
  <div class="menu-grid reveal">
    <?php foreach ($feedbacks as $fb): ?>
    <div class="fb-card">
      <div class="fb-name"><?= sanitize($fb['name']) ?></div>
      <div class="fb-stars"><?= str_repeat('★', $fb['rating']) . str_repeat('☆', 5 - $fb['rating']) ?></div>
      <div class="fb-comment"><?= sanitize($fb['comment']) ?></div>
      <div class="fb-date"><?= date('d M Y', strtotime($fb['created_at'])) ?></div>
    </div>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<!-- CTA -->
<section style="background:var(--dark-roast);padding:4rem 5%;text-align:center">
  <p class="section-label" style="color:var(--latte)">Reserve Your Moment</p>
  <h2 class="section-title" style="color:var(--cream);margin:0 auto 1rem;max-width:500px">Your Perfect Table Awaits</h2>
  <p style="color:rgba(245,230,208,.7);max-width:420px;margin:0 auto 2rem;line-height:1.8">Whether it's a quiet morning or a joyful celebration — we're ready for you.</p>
  <a href="<?= SITE_URL ?>/reserve.php" class="btn btn-primary">Book a Table Now</a>
</section>

<?php require_once 'includes/footer.php'; ?>
