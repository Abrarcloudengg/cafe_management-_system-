<?php
require_once '../config.php';
require_once '../includes/auth.php';
requireAdmin();
$adminPageTitle = 'Orders';
$db = getDB();
$msg = ''; $msgType = 'success';

// UPDATE STATUS
if (isset($_GET['status']) && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $validStatuses = ['pending','preparing','ready','delivered','cancelled'];
    $st = in_array($_GET['status'], $validStatuses) ? $_GET['status'] : 'pending';
    $db->prepare("UPDATE orders SET status = ? WHERE id = ?")->execute([$st, $id]);
    $msg = 'Order status updated to ' . ucfirst($st) . '.';
}

// DELETE
if (isset($_GET['delete'])) {
    $db->prepare("DELETE FROM orders WHERE id = ?")->execute([intval($_GET['delete'])]);
    $msg = 'Order deleted.';
}

$filter = $_GET['filter'] ?? 'all';
$where  = $filter !== 'all' ? "WHERE o.status = '$filter'" : '';
$orders = $db->query("SELECT o.*, u.email as uemail FROM orders o LEFT JOIN users u ON o.user_id = u.id $where ORDER BY o.created_at DESC")->fetchAll();
$STATUSES = ['pending','preparing','ready','delivered','cancelled'];
?>
<?php require_once 'includes/admin_header.php'; ?>

<?php if ($msg): ?><div class="alert alert-<?= $msgType ?>"><?= sanitize($msg) ?></div><?php endif; ?>

<div style="display:flex;gap:.6rem;margin-bottom:1.2rem;flex-wrap:wrap">
  <?php foreach (array_merge(['all'], $STATUSES) as $f): ?>
    <a href="orders.php?filter=<?= $f ?>" class="abtn <?= $filter === $f ? 'abtn-primary' : 'abtn-secondary' ?>"><?= ucfirst($f) ?></a>
  <?php endforeach; ?>
</div>

<div class="table-card">
  <div class="table-card-header">
    <h3>Orders (<?= count($orders) ?>)</h3>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>#</th><th>Customer</th><th>Item</th><th>Qty</th><th>Total</th><th>Type</th><th>Payment</th><th>UPI Ref</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
        <?php foreach ($orders as $o): ?>
        <tr>
          <td>#<?= $o['id'] ?></td>
          <td>
            <strong><?= sanitize($o['customer_name']) ?></strong><br>
            <span style="font-size:.75rem;color:#888"><?= sanitize($o['mobile']) ?></span>
          </td>
          <td><?= sanitize($o['item_name']) ?></td>
          <td><?= $o['quantity'] ?></td>
          <td>₹<?= number_format($o['total'], 0) ?></td>
          <td><?= ucfirst(str_replace('_', ' ', $o['order_type'])) ?></td>
          <td><?= ucfirst($o['payment_method']) ?></td>
          <td><?= $o['upi_ref'] ? sanitize($o['upi_ref']) : '—' ?></td>
          <td><span class="badge badge-<?= $o['status'] ?>"><?= ucfirst($o['status']) ?></span></td>
          <td class="actions">
            <?php foreach ($STATUSES as $s): ?>
              <?php if ($s !== $o['status']): ?>
                <a href="orders.php?id=<?= $o['id'] ?>&status=<?= $s ?>" class="abtn abtn-<?= $s === 'cancelled' ? 'danger' : ($s === 'delivered' ? 'info' : 'success') ?>" style="font-size:.68rem;padding:.3rem .6rem">
                  <?= ucfirst($s) ?>
                </a>
              <?php endif; ?>
            <?php endforeach; ?>
            <a href="orders.php?delete=<?= $o['id'] ?>" class="abtn abtn-danger confirm-delete" onclick="return confirm('Delete order?')">🗑️</a>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($orders)): ?><tr><td colspan="10" style="text-align:center;color:#888">No orders found.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once 'includes/admin_footer.php'; ?>
