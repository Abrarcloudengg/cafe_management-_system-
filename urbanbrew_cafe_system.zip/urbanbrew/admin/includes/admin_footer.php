  </div><!-- /content -->
</div><!-- /main-wrap -->
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
<script>
// Show sidebar toggle on mobile
if (window.innerWidth <= 768) {
  document.getElementById('sidebarToggle').style.display = 'block';
}
window.addEventListener('resize', function() {
  const btn = document.getElementById('sidebarToggle');
  if (btn) btn.style.display = window.innerWidth <= 768 ? 'block' : 'none';
});
</script>
</body>
</html>
