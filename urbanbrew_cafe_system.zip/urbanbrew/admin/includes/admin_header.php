<?php
// admin/includes/admin_header.php
$adminPageTitle = isset($adminPageTitle) ? $adminPageTitle . ' — Admin' : 'Admin Panel';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title><?= htmlspecialchars($adminPageTitle) ?> | Urban Brew</title>
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700;900&family=Lato:wght@300;400;700&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/admin.css"/>
</head>
<body>
<div class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <div class="logo">Urban <span>Brew</span></div>
    <p>Management System</p>
  </div>
  <nav class="sidebar-nav">
    <p class="nav-section-label">Main</p>
    <a href="<?= SITE_URL ?>/admin/dashboard.php" class="<?= (basename($_SERVER['PHP_SELF']) === 'dashboard.php') ? 'active' : '' ?>">
      <span class="icon">📊</span> Dashboard
    </a>
    <p class="nav-section-label">Manage</p>
    <a href="<?= SITE_URL ?>/admin/users.php" class="<?= (basename($_SERVER['PHP_SELF']) === 'users.php') ? 'active' : '' ?>">
      <span class="icon">👥</span> Users
    </a>
    <a href="<?= SITE_URL ?>/admin/reservations.php" class="<?= (strpos($_SERVER['PHP_SELF'], 'reservation') !== false) ? 'active' : '' ?>">
      <span class="icon">📅</span> Reservations
    </a>
    <a href="<?= SITE_URL ?>/admin/orders.php" class="<?= (strpos($_SERVER['PHP_SELF'], 'order') !== false) ? 'active' : '' ?>">
      <span class="icon">🛒</span> Orders
    </a>
    <a href="<?= SITE_URL ?>/admin/feedback.php" class="<?= (strpos($_SERVER['PHP_SELF'], 'feedback') !== false) ? 'active' : '' ?>">
      <span class="icon">💬</span> Feedback
    </a>
  </nav>
  <div class="sidebar-footer">
    <a href="<?= SITE_URL ?>" target="_blank"><span>🌐</span> View Website</a>
    <a href="<?= SITE_URL ?>/admin/logout.php" style="margin-top:.5rem"><span>🚪</span> Logout</a>
  </div>
</div>
<div class="main-wrap">
  <div class="topbar">
    <div style="display:flex;align-items:center;gap:1rem">
      <button id="sidebarToggle" style="display:none;background:none;border:none;cursor:pointer;font-size:1.4rem;color:var(--primary)" onclick="document.getElementById('sidebar').classList.toggle('open')">☰</button>
      <h1><?= htmlspecialchars($adminPageTitle) ?></h1>
    </div>
    <div class="topbar-right">
      <span class="admin-badge">👤 <?= htmlspecialchars($_SESSION['admin_name'] ?? 'Admin') ?></span>
      <a href="<?= SITE_URL ?>/admin/logout.php" style="font-size:.82rem;color:#dc3545;font-weight:700">Logout</a>
    </div>
  </div>
  <div class="content">
