<?php
require_once '../config.php';
unset($_SESSION['admin_id'], $_SESSION['admin_name']);
session_destroy();
header('Location: ' . SITE_URL . '/admin/login.php');
exit;
