<?php
require_once '../config.php';
require_once '../includes/auth.php';
requireAdmin();
$adminPageTitle = 'Users';
$db = getDB();
$msg = ''; $msgType = 'success';

// DELETE
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $db->prepare("DELETE FROM users WHERE id = ?")->execute([$id]);
    $msg = 'User deleted successfully.';
}

// EDIT (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_id'])) {
    $id     = intval($_POST['edit_id']);
    $name   = trim($_POST['name'] ?? '');
    $email  = trim($_POST['email'] ?? '');
    $mobile = trim($_POST['mobile'] ?? '');
    $errors = [];
    if (!$name) $errors[] = 'Name required.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email required.';
    if (empty($errors)) {
        $check = $db->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
        $check->execute([$email, $id]);
        if ($check->fetch()) { $msg = 'Email already used by another user.'; $msgType = 'danger'; }
        else {
            $db->prepare("UPDATE users SET name=?, email=?, mobile=? WHERE id=?")->execute([$name,$email,$mobile,$id]);
            $msg = 'User updated successfully.';
        }
    } else { $msg = implode(' ', $errors); $msgType = 'danger'; }
}

$editUser = null;
if (isset($_GET['edit'])) {
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([intval($_GET['edit'])]);
    $editUser = $stmt->fetch();
}

$users = $db->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll();
?>
<?php require_once 'includes/admin_header.php'; ?>

<?php if ($msg): ?><div class="alert alert-<?= $msgType ?>"><?= sanitize($msg) ?></div><?php endif; ?>

<?php if ($editUser): ?>
<!-- EDIT FORM -->
<div class="admin-form-card" style="margin-bottom:1.5rem">
  <h2>Edit User #<?= $editUser['id'] ?></h2>
  <form method="POST">
    <input type="hidden" name="edit_id" value="<?= $editUser['id'] ?>"/>
    <div class="afg-row">
      <div class="afg"><label>Full Name</label><input type="text" name="name" value="<?= sanitize($editUser['name']) ?>" required/></div>
      <div class="afg"><label>Mobile</label><input type="tel" name="mobile" value="<?= sanitize($editUser['mobile']) ?>"/></div>
    </div>
    <div class="afg"><label>Email</label><input type="email" name="email" value="<?= sanitize($editUser['email']) ?>" required/></div>
    <div style="display:flex;gap:.8rem">
      <button type="submit" class="admin-submit">Save Changes</button>
      <a href="users.php" class="abtn abtn-secondary" style="padding:.8rem 1.5rem">Cancel</a>
    </div>
  </form>
</div>
<?php endif; ?>

<div class="table-card">
  <div class="table-card-header">
    <h3>All Users (<?= count($users) ?>)</h3>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr><th>#</th><th>Name</th><th>Email</th><th>Mobile</th><th>Registered</th><th>Actions</th></tr>
      </thead>
      <tbody>
        <?php foreach ($users as $u): ?>
        <tr>
          <td><?= $u['id'] ?></td>
          <td><strong><?= sanitize($u['name']) ?></strong></td>
          <td><?= sanitize($u['email']) ?></td>
          <td><?= sanitize($u['mobile']) ?></td>
          <td><?= date('d M Y', strtotime($u['created_at'])) ?></td>
          <td class="actions">
            <a href="users.php?edit=<?= $u['id'] ?>" class="abtn abtn-warning">✏️ Edit</a>
            <a href="users.php?delete=<?= $u['id'] ?>" class="abtn abtn-danger confirm-delete" onclick="return confirm('Delete this user?')">🗑️ Delete</a>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($users)): ?><tr><td colspan="6" style="text-align:center;color:#888">No users registered yet.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once 'includes/admin_footer.php'; ?>
