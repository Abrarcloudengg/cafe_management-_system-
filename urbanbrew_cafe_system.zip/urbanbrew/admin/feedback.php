<?php
require_once '../config.php';
require_once '../includes/auth.php';
requireAdmin();
$adminPageTitle = 'Feedback';
$db = getDB();
$msg = '';

if (isset($_GET['delete'])) {
    $db->prepare("DELETE FROM feedback WHERE id = ?")->execute([intval($_GET['delete'])]);
    $msg = 'Feedback deleted.';
}

$feedbacks = $db->query("SELECT f.*, u.email as uemail FROM feedback f LEFT JOIN users u ON f.user_id = u.id ORDER BY f.created_at DESC")->fetchAll();
$avgRating = $db->query("SELECT ROUND(AVG(rating),1) FROM feedback")->fetchColumn();
?>
<?php require_once 'includes/admin_header.php'; ?>

<?php if ($msg): ?><div class="alert alert-success"><?= sanitize($msg) ?></div><?php endif; ?>

<!-- Summary -->
<div class="stats-grid" style="margin-bottom:1.5rem">
  <div class="stat-card feedback" style="border-color:#f4c542">
    <div class="ic">⭐</div>
    <div class="info"><div class="num"><?= $avgRating ?: '—' ?></div><div class="lbl">Avg Rating</div></div>
  </div>
  <div class="stat-card feedback">
    <div class="ic">💬</div>
    <div class="info"><div class="num"><?= count($feedbacks) ?></div><div class="lbl">Total Reviews</div></div>
  </div>
</div>

<div class="table-card">
  <div class="table-card-header"><h3>All Feedback</h3></div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>#</th><th>Name</th><th>Email</th><th>Rating</th><th>Comment</th><th>Date</th><th>Actions</th></tr></thead>
      <tbody>
        <?php foreach ($feedbacks as $f): ?>
        <tr>
          <td><?= $f['id'] ?></td>
          <td><strong><?= sanitize($f['name']) ?></strong></td>
          <td><?= sanitize($f['email'] ?: ($f['uemail'] ?: '—')) ?></td>
          <td style="color:#c07941;font-size:1rem"><?= str_repeat('★', $f['rating']) ?><span style="color:#ddd"><?= str_repeat('★', 5-$f['rating']) ?></span></td>
          <td style="max-width:300px"><?= sanitize($f['comment']) ?></td>
          <td><?= date('d M Y', strtotime($f['created_at'])) ?></td>
          <td><a href="feedback.php?delete=<?= $f['id'] ?>" class="abtn abtn-danger confirm-delete" onclick="return confirm('Delete feedback?')">🗑️ Delete</a></td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($feedbacks)): ?><tr><td colspan="7" style="text-align:center;color:#888">No feedback yet.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once 'includes/admin_footer.php'; ?>
