<?php
require_once '../config.php';
require_once '../includes/auth.php';
if (isAdmin()) redirect(SITE_URL . '/admin/dashboard.php');
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $pass  = $_POST['password'] ?? '';
    if (!$email || !$pass) {
        $error = 'Both fields are required.';
    } else {
        $db   = getDB();
        $stmt = $db->prepare("SELECT id, name, password FROM admins WHERE email = ?");
        $stmt->execute([$email]);
        $admin = $stmt->fetch();
        if ($admin && password_verify($pass, $admin['password'])) {
            $_SESSION['admin_id']   = $admin['id'];
            $_SESSION['admin_name'] = $admin['name'];
            redirect(SITE_URL . '/admin/dashboard.php');
        } else {
            $error = 'Invalid admin credentials.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Admin Login — Urban Brew</title>
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700;900&family=Lato:wght@300;400;700&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/admin.css"/>
</head>
<body style="display:block;background:linear-gradient(135deg,#2c1503,#6b3a1f)">
<div class="admin-login-wrap">
  <div class="admin-login-box">
    <div class="brand">
      <div class="logo-text">Urban <span>Brew</span></div>
      <p>Admin Control Panel</p>
    </div>
    <?php if ($error): ?><div class="alert alert-danger"><?= sanitize($error) ?></div><?php endif; ?>
    <?php if (($_GET['msg'] ?? '') === 'admin_required'): ?><div class="alert alert-info">Admin access required.</div><?php endif; ?>
    <form method="POST">
      <div class="afg">
        <label>Email Address</label>
        <input type="email" name="email" placeholder="admin@urbanbrew.com" value="<?= sanitize($_POST['email'] ?? '') ?>" required/>
      </div>
      <div class="afg">
        <label>Password</label>
        <input type="password" name="password" placeholder="Your password" required/>
      </div>
      <button type="submit" class="admin-submit" style="width:100%;padding:.9rem">Login to Admin Panel</button>
    </form>
    <p style="text-align:center;margin-top:1.2rem;font-size:.82rem;color:#aaa">
      <a href="<?= SITE_URL ?>" style="color:#c07941">← Back to Website</a>
    </p>
    <p style="text-align:center;margin-top:.5rem;font-size:.75rem;color:#bbb">
      Default: admin@urbanbrew.com / <strong>password</strong>
    </p>
  </div>
</div>
</body>
</html>
