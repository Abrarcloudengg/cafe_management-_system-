<?php
require_once '../config.php';
require_once '../includes/auth.php';
requireAdmin();
$adminPageTitle = 'Dashboard';
$db = getDB();

$totalUsers    = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
$totalOrders   = $db->query("SELECT COUNT(*) FROM orders")->fetchColumn();
$totalReserves = $db->query("SELECT COUNT(*) FROM reservations")->fetchColumn();
$totalFeedback = $db->query("SELECT COUNT(*) FROM feedback")->fetchColumn();
$pendingOrders = $db->query("SELECT COUNT(*) FROM orders WHERE status = 'pending'")->fetchColumn();
$pendingRes    = $db->query("SELECT COUNT(*) FROM reservations WHERE status = 'pending'")->fetchColumn();
$recentOrders  = $db->query("SELECT o.*, u.name as uname FROM orders o LEFT JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC LIMIT 8")->fetchAll();
$recentUsers   = $db->query("SELECT * FROM users ORDER BY created_at DESC LIMIT 5")->fetchAll();
?>
<?php require_once 'includes/admin_header.php'; ?>

<!-- STATS -->
<div class="stats-grid">
  <div class="stat-card users">
    <div class="ic">👥</div>
    <div class="info"><div class="num"><?= $totalUsers ?></div><div class="lbl">Total Users</div></div>
  </div>
  <div class="stat-card orders">
    <div class="ic">🛒</div>
    <div class="info"><div class="num"><?= $totalOrders ?></div><div class="lbl">Total Orders</div></div>
  </div>
  <div class="stat-card reservations">
    <div class="ic">📅</div>
    <div class="info"><div class="num"><?= $totalReserves ?></div><div class="lbl">Reservations</div></div>
  </div>
  <div class="stat-card feedback">
    <div class="ic">💬</div>
    <div class="info"><div class="num"><?= $totalFeedback ?></div><div class="lbl">Feedbacks</div></div>
  </div>
</div>

<!-- ALERTS -->
<?php if ($pendingOrders > 0): ?>
  <div class="alert alert-info" style="margin-bottom:1rem">⚡ <strong><?= $pendingOrders ?> pending order(s)</strong> need attention. <a href="orders.php" style="color:inherit;text-decoration:underline">View orders →</a></div>
<?php endif; ?>
<?php if ($pendingRes > 0): ?>
  <div class="alert alert-info" style="margin-bottom:1rem">📅 <strong><?= $pendingRes ?> reservation(s)</strong> awaiting approval. <a href="reservations.php" style="color:inherit;text-decoration:underline">View reservations →</a></div>
<?php endif; ?>

<div style="display:grid;grid-template-columns:2fr 1fr;gap:1.5rem;flex-wrap:wrap">
  <!-- Recent Orders -->
  <div class="table-card">
    <div class="table-card-header">
      <h3>Recent Orders</h3>
      <a href="orders.php" class="abtn abtn-primary">View All</a>
    </div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>#</th><th>Customer</th><th>Item</th><th>Total</th><th>Type</th><th>Status</th><th>Date</th></tr></thead>
        <tbody>
          <?php foreach ($recentOrders as $o): ?>
          <tr>
            <td>#<?= $o['id'] ?></td>
            <td><?= sanitize($o['customer_name']) ?></td>
            <td><?= sanitize($o['item_name']) ?></td>
            <td>₹<?= number_format($o['total'], 0) ?></td>
            <td><?= ucfirst(str_replace('_', ' ', $o['order_type'])) ?></td>
            <td><span class="badge badge-<?= $o['status'] ?>"><?= ucfirst($o['status']) ?></span></td>
            <td><?= date('d M', strtotime($o['created_at'])) ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Recent Users -->
  <div class="table-card">
    <div class="table-card-header">
      <h3>New Users</h3>
      <a href="users.php" class="abtn abtn-primary">View All</a>
    </div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Name</th><th>Joined</th></tr></thead>
        <tbody>
          <?php foreach ($recentUsers as $u): ?>
          <tr>
            <td>
              <strong><?= sanitize($u['name']) ?></strong><br>
              <span style="font-size:.75rem;color:#888"><?= sanitize($u['email']) ?></span>
            </td>
            <td><?= date('d M Y', strtotime($u['created_at'])) ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php require_once 'includes/admin_footer.php'; ?>
