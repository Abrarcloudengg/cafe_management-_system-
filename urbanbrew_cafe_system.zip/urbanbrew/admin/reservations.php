<?php
require_once '../config.php';
require_once '../includes/auth.php';
requireAdmin();
$adminPageTitle = 'Reservations';
$db = getDB();
$msg = ''; $msgType = 'success';

// UPDATE STATUS
if (isset($_GET['status']) && isset($_GET['id'])) {
    $id  = intval($_GET['id']);
    $st  = in_array($_GET['status'], ['pending','approved','cancelled']) ? $_GET['status'] : 'pending';
    $db->prepare("UPDATE reservations SET status = ? WHERE id = ?")->execute([$st, $id]);
    $msg = 'Reservation status updated to ' . ucfirst($st) . '.';
}

// DELETE
if (isset($_GET['delete'])) {
    $db->prepare("DELETE FROM reservations WHERE id = ?")->execute([intval($_GET['delete'])]);
    $msg = 'Reservation deleted.';
}

// EDIT POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_id'])) {
    $id      = intval($_POST['edit_id']);
    $name    = trim($_POST['customer_name'] ?? '');
    $mobile  = trim($_POST['mobile'] ?? '');
    $guests  = intval($_POST['guests'] ?? 1);
    $date    = $_POST['date'] ?? '';
    $time    = $_POST['time'] ?? '';
    $request = trim($_POST['special_request'] ?? '');
    $status  = $_POST['status'] ?? 'pending';
    $db->prepare("UPDATE reservations SET customer_name=?,mobile=?,guests=?,date=?,time=?,special_request=?,status=? WHERE id=?")
       ->execute([$name,$mobile,$guests,$date,$time,$request,$status,$id]);
    $msg = 'Reservation updated.';
}

$editRes = null;
if (isset($_GET['edit'])) {
    $stmt = $db->prepare("SELECT * FROM reservations WHERE id = ?");
    $stmt->execute([intval($_GET['edit'])]);
    $editRes = $stmt->fetch();
}

$filter = $_GET['filter'] ?? 'all';
$where  = $filter !== 'all' ? "WHERE status = '$filter'" : '';
$reservations = $db->query("SELECT r.*, u.email as uemail FROM reservations r LEFT JOIN users u ON r.user_id = u.id $where ORDER BY r.created_at DESC")->fetchAll();
?>
<?php require_once 'includes/admin_header.php'; ?>

<?php if ($msg): ?><div class="alert alert-<?= $msgType ?>"><?= sanitize($msg) ?></div><?php endif; ?>

<!-- Filter -->
<div style="display:flex;gap:.6rem;margin-bottom:1.2rem;flex-wrap:wrap">
  <?php foreach (['all','pending','approved','cancelled'] as $f): ?>
    <a href="reservations.php?filter=<?= $f ?>" class="abtn <?= $filter === $f ? 'abtn-primary' : 'abtn-secondary' ?>"><?= ucfirst($f) ?></a>
  <?php endforeach; ?>
</div>

<?php if ($editRes): ?>
<div class="admin-form-card" style="margin-bottom:1.5rem">
  <h2>Edit Reservation #<?= $editRes['id'] ?></h2>
  <form method="POST">
    <input type="hidden" name="edit_id" value="<?= $editRes['id'] ?>"/>
    <div class="afg-row">
      <div class="afg"><label>Customer Name</label><input type="text" name="customer_name" value="<?= sanitize($editRes['customer_name']) ?>" required/></div>
      <div class="afg"><label>Mobile</label><input type="tel" name="mobile" value="<?= sanitize($editRes['mobile']) ?>"/></div>
    </div>
    <div class="afg-row">
      <div class="afg"><label>Guests</label><input type="number" name="guests" value="<?= $editRes['guests'] ?>" min="1" max="20"/></div>
      <div class="afg">
        <label>Status</label>
        <select name="status">
          <?php foreach (['pending','approved','cancelled'] as $s): ?>
            <option value="<?= $s ?>" <?= $editRes['status'] === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>
    <div class="afg-row">
      <div class="afg"><label>Date</label><input type="date" name="date" value="<?= $editRes['date'] ?>"/></div>
      <div class="afg"><label>Time</label><input type="time" name="time" value="<?= $editRes['time'] ?>"/></div>
    </div>
    <div class="afg"><label>Special Request</label><textarea name="special_request"><?= sanitize($editRes['special_request']) ?></textarea></div>
    <div style="display:flex;gap:.8rem">
      <button type="submit" class="admin-submit">Save Changes</button>
      <a href="reservations.php" class="abtn abtn-secondary" style="padding:.8rem 1.5rem">Cancel</a>
    </div>
  </form>
</div>
<?php endif; ?>

<div class="table-card">
  <div class="table-card-header">
    <h3>Reservations (<?= count($reservations) ?>)</h3>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>#</th><th>Name</th><th>Mobile</th><th>Guests</th><th>Date</th><th>Time</th><th>Special Request</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
        <?php foreach ($reservations as $r): ?>
        <tr>
          <td><?= $r['id'] ?></td>
          <td><strong><?= sanitize($r['customer_name']) ?></strong><br><span style="font-size:.75rem;color:#888"><?= sanitize($r['uemail'] ?? '') ?></span></td>
          <td><?= sanitize($r['mobile']) ?></td>
          <td><?= $r['guests'] ?></td>
          <td><?= date('d M Y', strtotime($r['date'])) ?></td>
          <td><?= date('h:i A', strtotime($r['time'])) ?></td>
          <td><?= $r['special_request'] ? sanitize($r['special_request']) : '—' ?></td>
          <td><span class="badge badge-<?= $r['status'] ?>"><?= ucfirst($r['status']) ?></span></td>
          <td class="actions">
            <a href="reservations.php?id=<?= $r['id'] ?>&status=approved" class="abtn abtn-success">✅ Approve</a>
            <a href="reservations.php?id=<?= $r['id'] ?>&status=cancelled" class="abtn abtn-warning">❌ Cancel</a>
            <a href="reservations.php?edit=<?= $r['id'] ?>" class="abtn abtn-info">✏️</a>
            <a href="reservations.php?delete=<?= $r['id'] ?>" class="abtn abtn-danger confirm-delete" onclick="return confirm('Delete?')">🗑️</a>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($reservations)): ?><tr><td colspan="9" style="text-align:center;color:#888">No reservations found.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once 'includes/admin_footer.php'; ?>
