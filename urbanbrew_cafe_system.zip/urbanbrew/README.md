# 🍵 Urban Brew Cafe Management System
## Complete Setup Guide for XAMPP

---

## 📁 Project Structure

```
urbanbrew/
├── admin/
│   ├── includes/
│   │   ├── admin_header.php
│   │   └── admin_footer.php
│   ├── dashboard.php
│   ├── users.php
│   ├── reservations.php
│   ├── orders.php
│   ├── feedback.php
│   ├── login.php
│   └── logout.php
├── assets/
│   ├── css/
│   │   ├── style.css       (frontend)
│   │   └── admin.css       (admin panel)
│   └── js/
│       └── main.js
├── includes/
│   ├── header.php
│   ├── footer.php
│   └── auth.php
├── sql/
│   └── urbanbrew.sql       ← Import this first!
├── config.php              ← Edit DB credentials here
├── index.php               (Homepage)
├── register.php
├── login.php
├── logout.php
├── reserve.php
├── order.php
├── feedback.php
└── profile.php
```

---

## ⚙️ Step-by-Step XAMPP Setup

### Step 1 — Install XAMPP
Download from: https://www.apachefriends.org
Install and open **XAMPP Control Panel**

### Step 2 — Start Servers
- Click **Start** next to **Apache**
- Click **Start** next to **MySQL**
Both should show green status.

### Step 3 — Place Project Files
Copy the entire `urbanbrew` folder to:
```
C:\xampp\htdocs\urbanbrew\
```

### Step 4 — Create the Database
1. Open browser → go to: **http://localhost/phpmyadmin**
2. Click **"New"** in the left sidebar
3. Create database named: `urbanbrew_db`
4. Click the database → click **"Import"** tab
5. Choose file: `urbanbrew/sql/urbanbrew.sql`
6. Click **"Go"**

You should see 5 tables created:
- admins, users, reservations, orders, feedback

### Step 5 — Configure Database (if needed)
Open `config.php` and update if your XAMPP settings differ:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');          // empty by default in XAMPP
define('DB_NAME', 'urbanbrew_db');
define('SITE_URL', 'http://localhost/urbanbrew');
```

### Step 6 — Open the Website
- **Frontend:** http://localhost/urbanbrew
- **Admin Panel:** http://localhost/urbanbrew/admin/login.php

---

## 🔐 Default Login Credentials

### Admin Panel
| Field    | Value                    |
|----------|--------------------------|
| Email    | admin@urbanbrew.com      |
| Password | password                 |

> ⚠️ Change these immediately after first login!

To update admin password:
1. Go to phpMyAdmin → urbanbrew_db → admins table
2. Run this SQL to set a new password:
```sql
UPDATE admins
SET password = '$2y$10$YourNewHashHere'
WHERE email = 'admin@urbanbrew.com';
```
Or use PHP's `password_hash('YourNewPassword', PASSWORD_DEFAULT)` to generate a hash.

### Customer Registration
Use the Register page: http://localhost/urbanbrew/register.php

---

## 🗄️ Database Tables

### users
| Column     | Type         | Notes              |
|------------|--------------|---------------------|
| id         | INT PK AI    | Auto increment      |
| name       | VARCHAR(100) |                     |
| email      | VARCHAR(150) | UNIQUE              |
| mobile     | VARCHAR(20)  |                     |
| password   | VARCHAR(255) | Hashed with bcrypt  |
| created_at | TIMESTAMP    |                     |

### reservations
| Column          | Type         | Notes              |
|-----------------|--------------|---------------------|
| id              | INT PK AI    |                     |
| user_id         | INT FK       | → users.id          |
| customer_name   | VARCHAR(100) |                     |
| mobile          | VARCHAR(20)  |                     |
| guests          | INT          |                     |
| date            | DATE         |                     |
| time            | TIME         |                     |
| special_request | TEXT         |                     |
| status          | ENUM         | pending/approved/cancelled |

### orders
| Column         | Type         | Notes              |
|----------------|--------------|---------------------|
| id             | INT PK AI    |                     |
| user_id        | INT FK       | → users.id          |
| customer_name  | VARCHAR(100) |                     |
| mobile         | VARCHAR(20)  |                     |
| item_name      | VARCHAR(150) |                     |
| quantity       | INT          |                     |
| price          | DECIMAL      | Per item price      |
| total          | DECIMAL      | Including delivery  |
| order_type     | ENUM         | dine_in/takeaway/delivery |
| address        | TEXT         | For delivery orders |
| payment_method | ENUM         | upi/cash/card       |
| upi_ref        | VARCHAR(100) |                     |
| status         | ENUM         | pending/preparing/ready/delivered/cancelled |

### feedback
| Column     | Type        | Notes             |
|------------|-------------|-------------------|
| id         | INT PK AI   |                   |
| user_id    | INT FK      | → users.id        |
| name       | VARCHAR(100)|                   |
| email      | VARCHAR(150)|                   |
| rating     | TINYINT     | 1–5               |
| comment    | TEXT        |                   |
| created_at | TIMESTAMP   |                   |

---

## 🛡️ Security Features
- ✅ All queries use PDO Prepared Statements (SQL injection prevention)
- ✅ Passwords hashed with `password_hash()` (bcrypt)
- ✅ Session-based authentication (user + admin separated)
- ✅ Input sanitized with `htmlspecialchars()` before output
- ✅ Admin routes protected with `requireAdmin()`
- ✅ User routes protected with `requireLogin()` where needed
- ✅ PDO error mode set to EXCEPTION

---

## ✨ Feature Summary

### Frontend (Customer)
- Homepage with Menu, Gallery, Team, Feedback showcase
- Customer Registration & Login
- Table Reservation form
- Online Order (Dine In / Takeaway / Home Delivery)
- UPI Payment QR Code
- Feedback submission with star rating
- Profile page showing orders & reservations

### Admin Panel
- Dashboard with live stats
- User management (View, Edit, Delete)
- Reservation management (Approve, Cancel, Edit, Delete)
- Order management (Update status through all stages, Delete)
- Feedback management (View, Delete, Average rating)

---

## 📞 Contact Info in System
- Phone: +91 8669046436
- Address: Station Road, Kolhapur, Maharashtra — 416001
- Hours: Mon–Sun 7am–10pm

---

*Urban Brew Cafe Management System — Built with PHP, MySQL, HTML, CSS, Vanilla JS*
