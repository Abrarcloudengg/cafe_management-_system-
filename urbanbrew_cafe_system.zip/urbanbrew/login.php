<?php
require_once 'config.php';
require_once 'includes/auth.php';
if (isLoggedIn()) redirect(SITE_URL . '/profile.php');
$pageTitle = 'Login';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $pass  = $_POST['password'] ?? '';

    if (!$email || !$pass) {
        $errors[] = 'Both fields are required.';
    } else {
        $db   = getDB();
        $stmt = $db->prepare("SELECT id, name, password FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        if ($user && password_verify($pass, $user['password'])) {
            $_SESSION['user_id']   = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            redirect(SITE_URL . '/profile.php');
        } else {
            $errors[] = 'Invalid email or password.';
        }
    }
}
$msg = $_GET['msg'] ?? '';
?>
<?php require_once 'includes/header.php'; ?>
<div class="page-wrap" style="display:flex;align-items:center;justify-content:center;padding:6rem 1.5rem 3rem">
  <div class="form-box" style="width:100%">
    <h2>Welcome Back</h2>
    <p class="sub">Login to your Urban Brew account.</p>
    <?php if ($msg === 'login_required'): ?><div class="alert alert-warning">Please login to continue.</div><?php endif; ?>
    <?php foreach ($errors as $e): ?><div class="alert alert-error"><?= sanitize($e) ?></div><?php endforeach; ?>
    <form method="POST" novalidate>
      <div class="form-group">
        <label>Email Address</label>
        <input type="email" name="email" value="<?= sanitize($_POST['email'] ?? '') ?>" placeholder="rahul@example.com" required/>
      </div>
      <div class="form-group">
        <label>Password</label>
        <input type="password" name="password" placeholder="Your password" required/>
      </div>
      <button type="submit" class="submit-btn">Login →</button>
    </form>
    <p style="text-align:center;margin-top:1.2rem;font-size:.9rem;color:var(--medium-roast)">
      Don't have an account? <a href="register.php" style="color:var(--caramel);font-weight:700">Register →</a>
    </p>
  </div>
</div>
<?php require_once 'includes/footer.php'; ?>
