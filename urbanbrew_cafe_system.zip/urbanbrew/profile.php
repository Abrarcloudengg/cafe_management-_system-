<?php
require_once 'config.php';
require_once 'includes/auth.php';
requireLogin();
$pageTitle = 'My Profile';
$db  = getDB();
$uid = $_SESSION['user_id'];

// Fetch user data
$user = $db->prepare("SELECT * FROM users WHERE id = ?");
$user->execute([$uid]);
$user = $user->fetch();

// Fetch user's reservations
$reserves = $db->prepare("SELECT * FROM reservations WHERE user_id = ? ORDER BY created_at DESC");
$reserves->execute([$uid]);
$reserves = $reserves->fetchAll();

// Fetch user's orders
$orders = $db->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC");
$orders->execute([$uid]);
$orders = $orders->fetchAll();
?>
<?php require_once 'includes/header.php'; ?>
<div class="page-section">
  <div class="container">
    <!-- Welcome Card -->
    <div class="card" style="margin-top:1rem;background:linear-gradient(135deg,var(--dark-roast),var(--medium-roast));color:#fff">
      <div style="display:flex;align-items:center;gap:1.5rem;flex-wrap:wrap">
        <div style="width:70px;height:70px;border-radius:50%;background:var(--caramel);display:flex;align-items:center;justify-content:center;font-size:2rem;font-family:'Playfair Display',serif;font-weight:900;flex-shrink:0">
          <?= strtoupper(substr($user['name'], 0, 1)) ?>
        </div>
        <div>
          <h2 style="font-family:'Playfair Display',serif;font-size:1.6rem;font-weight:700">Hello, <?= sanitize($user['name']) ?>!</h2>
          <p style="opacity:.75;font-size:.9rem">📧 <?= sanitize($user['email']) ?> &nbsp;|&nbsp; 📞 <?= sanitize($user['mobile']) ?></p>
          <p style="opacity:.6;font-size:.78rem;margin-top:.3rem">Member since <?= date('d M Y', strtotime($user['created_at'])) ?></p>
        </div>
      </div>
    </div>

    <!-- Quick actions -->
    <div style="display:flex;gap:1rem;margin-bottom:1.5rem;flex-wrap:wrap">
      <a href="reserve.php" class="btn btn-primary btn-sm">+ New Reservation</a>
      <a href="order.php" class="btn btn-primary btn-sm">+ Place Order</a>
      <a href="feedback.php" class="btn btn-outline btn-sm" style="color:var(--espresso);border-color:var(--caramel)">Give Feedback</a>
    </div>

    <!-- My Reservations -->
    <div class="card">
      <h3>My Reservations</h3>
      <?php if (empty($reserves)): ?>
        <p style="color:var(--medium-roast)">No reservations yet. <a href="reserve.php" style="color:var(--caramel)">Book a table →</a></p>
      <?php else: ?>
        <div style="overflow-x:auto">
          <table>
            <thead><tr><th>#</th><th>Date</th><th>Time</th><th>Guests</th><th>Special Request</th><th>Status</th></tr></thead>
            <tbody>
              <?php foreach ($reserves as $r): ?>
              <tr>
                <td><?= $r['id'] ?></td>
                <td><?= date('d M Y', strtotime($r['date'])) ?></td>
                <td><?= date('h:i A', strtotime($r['time'])) ?></td>
                <td><?= $r['guests'] ?></td>
                <td><?= $r['special_request'] ? sanitize($r['special_request']) : '—' ?></td>
                <td><span class="status-badge status-<?= $r['status'] ?>"><?= ucfirst($r['status']) ?></span></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>

    <!-- My Orders -->
    <div class="card">
      <h3>My Orders</h3>
      <?php if (empty($orders)): ?>
        <p style="color:var(--medium-roast)">No orders yet. <a href="order.php" style="color:var(--caramel)">Order now →</a></p>
      <?php else: ?>
        <div style="overflow-x:auto">
          <table>
            <thead><tr><th>#</th><th>Item</th><th>Qty</th><th>Total</th><th>Type</th><th>Payment</th><th>Status</th><th>Date</th></tr></thead>
            <tbody>
              <?php foreach ($orders as $o): ?>
              <tr>
                <td><?= $o['id'] ?></td>
                <td><?= sanitize($o['item_name']) ?></td>
                <td><?= $o['quantity'] ?></td>
                <td>₹<?= number_format($o['total'], 0) ?></td>
                <td><?= ucfirst(str_replace('_', ' ', $o['order_type'])) ?></td>
                <td><?= ucfirst($o['payment_method']) ?></td>
                <td><span class="status-badge status-<?= $o['status'] ?>"><?= ucfirst($o['status']) ?></span></td>
                <td><?= date('d M', strtotime($o['created_at'])) ?></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php require_once 'includes/footer.php'; ?>
