<?php
require_once 'config.php';
require_once 'includes/auth.php';
$pageTitle = 'Feedback';
$errors = []; $success = '';

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = trim($_POST['name'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $rating  = intval($_POST['rating'] ?? 0);
    $comment = trim($_POST['comment'] ?? '');

    if (!$name)    $errors[] = 'Name is required.';
    if ($rating < 1 || $rating > 5) $errors[] = 'Please select a rating.';
    if (!$comment) $errors[] = 'Comment is required.';

    if (empty($errors)) {
        $uid  = $_SESSION['user_id'] ?? null;
        $stmt = $db->prepare("INSERT INTO feedback (user_id,name,email,rating,comment) VALUES (?,?,?,?,?)");
        $stmt->execute([$uid,$name,$email,$rating,$comment]);
        $success = 'Thank you for your feedback!';
    }
}

$feedbacks = $db->query("SELECT name, rating, comment, created_at FROM feedback ORDER BY created_at DESC LIMIT 20")->fetchAll();
?>
<?php require_once 'includes/header.php'; ?>
<div class="page-section">
  <div class="container" style="max-width:680px">
    <div class="card" style="margin-top:1rem">
      <h2 style="font-family:'Playfair Display',serif;font-size:1.9rem;font-weight:700;margin-bottom:.3rem">Share Your Feedback</h2>
      <p style="color:var(--medium-roast);margin-bottom:1.5rem">Your words help us brew better every single day.</p>
      <?php foreach ($errors as $e): ?><div class="alert alert-error"><?= sanitize($e) ?></div><?php endforeach; ?>
      <?php if ($success): ?><div class="alert alert-success">💛 <?= $success ?></div><?php endif; ?>
      <form method="POST" novalidate>
        <div class="form-row">
          <div class="form-group">
            <label>Your Name</label>
            <input type="text" name="name" value="<?= sanitize($_POST['name'] ?? (isset($_SESSION['user_name']) ? $_SESSION['user_name'] : '')) ?>" placeholder="Your name" required/>
          </div>
          <div class="form-group">
            <label>Email <span style="font-weight:400;text-transform:none">(optional)</span></label>
            <input type="email" name="email" value="<?= sanitize($_POST['email'] ?? '') ?>" placeholder="your@email.com"/>
          </div>
        </div>
        <div class="form-group">
          <label>Rating</label>
          <div class="star-rating">
            <?php for ($i = 5; $i >= 1; $i--): ?>
              <input type="radio" name="rating" id="s<?= $i ?>" value="<?= $i ?>" <?= (($_POST['rating'] ?? '') == $i) ? 'checked' : '' ?>/>
              <label for="s<?= $i ?>">★</label>
            <?php endfor; ?>
          </div>
        </div>
        <div class="form-group">
          <label>Your Comment</label>
          <textarea name="comment" placeholder="Tell us about your experience..." required><?= sanitize($_POST['comment'] ?? '') ?></textarea>
        </div>
        <button type="submit" class="submit-btn">Submit Feedback →</button>
      </form>
    </div>

    <?php if (!empty($feedbacks)): ?>
    <div class="feedback-list">
      <h3 style="font-family:'Playfair Display',serif;font-size:1.4rem;margin-bottom:1rem;color:var(--espresso)">Guest Reviews</h3>
      <?php foreach ($feedbacks as $fb): ?>
      <div class="fb-card">
        <div class="fb-name"><?= sanitize($fb['name']) ?></div>
        <div class="fb-stars"><?= str_repeat('★', $fb['rating']) . str_repeat('☆', 5 - $fb['rating']) ?></div>
        <div class="fb-comment"><?= sanitize($fb['comment']) ?></div>
        <div class="fb-date"><?= date('d M Y', strtotime($fb['created_at'])) ?></div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php require_once 'includes/footer.php'; ?>
