// Urban Brew Cafe - Main JS

// Navbar scroll
window.addEventListener('scroll', () => {
  document.getElementById('navbar')?.classList.toggle('scrolled', window.scrollY > 50);
});

// Hamburger
const hamburger = document.getElementById('hamburger');
const mobileMenu = document.getElementById('mobileMenu');
if (hamburger && mobileMenu) {
  hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('open');
    mobileMenu.classList.toggle('open');
  });
  mobileMenu.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
    hamburger.classList.remove('open');
    mobileMenu.classList.remove('open');
  }));
}

// Scroll reveal
const revealObs = new IntersectionObserver((entries) => {
  entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('visible'); });
}, { threshold: 0.12 });
document.querySelectorAll('.reveal').forEach(el => revealObs.observe(el));

// Menu tabs (homepage)
const menuItems = [
  { cat:'coffee', name:'Espresso',       desc:'Rich, bold single shot of pure espresso perfection.',          price:'₹120', img:'https://images.unsplash.com/photo-1510591509098-f4fdc6d0ff04?w=600&q=80',  tag:'Classic'     },
  { cat:'coffee', name:'Cappuccino',     desc:'Velvety steamed milk over double espresso, topped with foam.', price:'₹150', img:'https://images.unsplash.com/photo-1534040385115-33dcb3acba5b?w=600&q=80',  tag:'Popular'     },
  { cat:'coffee', name:'Caramel Latte',  desc:'Smooth latte with house-made salted caramel drizzle.',         price:'₹180', img:'https://images.unsplash.com/photo-1485808191679-5f86510bd9d7?w=600&q=80',  tag:'Best Seller' },
  { cat:'coffee', name:'Flat White',     desc:'Australian-style double ristretto with silky micro-foam.',     price:'₹160', img:'https://images.unsplash.com/photo-1517701604599-bb29b565090c?w=600&q=80',  tag:'Barista Pick' },
  { cat:'cold',   name:'Cold Brew',      desc:'12-hour slow-steeped cold brew, bold and ultra-smooth.',       price:'₹170', img:'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?w=600&q=80',  tag:'Refreshing'  },
  { cat:'cold',   name:'Matcha Latte',   desc:'Ceremonial-grade matcha whisked with oat milk over ice.',      price:'₹190', img:'https://images.unsplash.com/photo-1536256263959-770b48d82b0a?w=600&q=80',  tag:'Vegan'       },
  { cat:'cold',   name:'Frappuccino',    desc:'Blended espresso, ice cream, and caramel — pure joy.',         price:'₹220', img:'https://images.unsplash.com/photo-1572490122747-3a9d5a87c40a?w=600&q=80',  tag:'Summer Fave' },
  { cat:'food',   name:'Butter Croissant',desc:'Flaky, golden, buttery — baked fresh every morning.',         price:'₹110', img:'https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=600&q=80',  tag:'Baked Fresh' },
  { cat:'food',   name:'Avocado Toast',  desc:'Sourdough, smashed avo, poached egg, chili flakes.',           price:'₹140', img:'https://images.unsplash.com/photo-1541519227354-08fa5d50c820?w=600&q=80',  tag:'Healthy'     },
  { cat:'food',   name:'Eggs Benedict',  desc:'Classic hollandaise on toasted English muffin with salmon.',   price:'₹190', img:'https://images.unsplash.com/photo-1608039829572-78524f79c4c7?w=600&q=80',  tag:'Brunch'      },
];

function renderMenu(filter) {
  const grid = document.getElementById('menuGrid');
  if (!grid) return;
  const items = filter === 'all' ? menuItems : menuItems.filter(i => i.cat === filter);
  grid.innerHTML = items.map(item => `
    <div class="menu-card">
      <div class="menu-card-img">
        <img src="${item.img}" alt="${item.name}" loading="lazy"
             onerror="this.src='https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=600&q=80'"/>
      </div>
      <div class="menu-card-body">
        <div class="menu-card-title">${item.name}</div>
        <div class="menu-card-desc">${item.desc}</div>
        <div class="menu-card-footer">
          <span class="price">${item.price}</span>
          <span class="badge-tag">${item.tag}</span>
        </div>
      </div>
    </div>
  `).join('');
}
renderMenu('all');

function filterMenu(cat, btn) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  renderMenu(cat);
}

// Order page logic
const MENU_PRICES = {
  'Espresso':120,'Cappuccino':150,'Flat White':160,'Caramel Latte':180,
  'Matcha Latte':190,'Cold Brew':170,'Frappuccino':220,
  'Butter Croissant':110,'Avocado Toast':140,'Eggs Benedict':190
};

function calcOrderTotal() {
  const itemEl = document.getElementById('ordItem');
  const qtyEl  = document.getElementById('ordQty');
  const totEl  = document.getElementById('ordTotal');
  if (!itemEl || !qtyEl || !totEl) return;
  const price = MENU_PRICES[itemEl.value] || 0;
  const qty   = parseInt(qtyEl.value) || 1;
  const type  = document.getElementById('ordType')?.value;
  const del   = type === 'delivery' && price > 0 ? 30 : 0;
  totEl.textContent = '₹' + (price * qty + del);
}

function setOrderType(type) {
  const typeEl = document.getElementById('ordType');
  if (typeEl) typeEl.value = type;
  document.querySelectorAll('.order-type-btn').forEach(b => b.classList.remove('active'));
  document.getElementById('btn_' + type)?.classList.add('active');
  const addrGrp   = document.getElementById('addrGroup');
  const delNotice = document.getElementById('delNotice');
  if (addrGrp)   addrGrp.style.display   = type === 'delivery' ? 'block' : 'none';
  if (delNotice) delNotice.style.display  = type === 'delivery' ? 'block' : 'none';
  calcOrderTotal();
}

function toggleUPI(radio) {
  const upiBlock = document.getElementById('upiBlock');
  const upiRef   = document.getElementById('upiRefGroup');
  if (upiBlock) upiBlock.style.display = radio.value === 'upi' ? 'block' : 'none';
  if (upiRef)   upiRef.style.display   = radio.value === 'upi' ? 'block' : 'none';
}

// Auto-dismiss alerts
document.querySelectorAll('.alert').forEach(alert => {
  setTimeout(() => { alert.style.opacity = '0'; setTimeout(() => alert.remove(), 400); }, 4000);
});

// Admin sidebar toggle (mobile)
document.getElementById('sidebarToggle')?.addEventListener('click', () => {
  document.querySelector('.sidebar')?.classList.toggle('open');
});

// Confirm delete
document.querySelectorAll('.confirm-delete').forEach(btn => {
  btn.addEventListener('click', e => {
    if (!confirm('Are you sure you want to delete this? This action cannot be undone.')) {
      e.preventDefault();
    }
  });
});
