-- ============================================
-- Urban Brew Cafe Management System
-- Database Schema
-- ============================================

CREATE DATABASE IF NOT EXISTS urbanbrew_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE urbanbrew_db;

-- ============================================
-- TABLE: admins
-- ============================================
CREATE TABLE IF NOT EXISTS admins (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    email       VARCHAR(150) NOT NULL UNIQUE,
    password    VARCHAR(255) NOT NULL,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Default admin: admin@urbanbrew.com / Admin@1234
INSERT INTO admins (name, email, password) VALUES
('Super Admin', 'admin@urbanbrew.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- ============================================
-- TABLE: users
-- ============================================
CREATE TABLE IF NOT EXISTS users (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    email       VARCHAR(150) NOT NULL UNIQUE,
    mobile      VARCHAR(20) NOT NULL,
    password    VARCHAR(255) NOT NULL,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================
-- TABLE: reservations
-- ============================================
CREATE TABLE IF NOT EXISTS reservations (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    user_id         INT,
    customer_name   VARCHAR(100) NOT NULL,
    mobile          VARCHAR(20) NOT NULL,
    guests          INT NOT NULL DEFAULT 1,
    date            DATE NOT NULL,
    time            TIME NOT NULL,
    special_request TEXT,
    status          ENUM('pending','approved','cancelled') DEFAULT 'pending',
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ============================================
-- TABLE: orders
-- ============================================
CREATE TABLE IF NOT EXISTS orders (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    user_id         INT,
    customer_name   VARCHAR(100) NOT NULL,
    mobile          VARCHAR(20) NOT NULL,
    item_name       VARCHAR(150) NOT NULL,
    quantity        INT NOT NULL DEFAULT 1,
    price           DECIMAL(10,2) NOT NULL,
    total           DECIMAL(10,2) NOT NULL,
    order_type      ENUM('dine_in','takeaway','delivery') DEFAULT 'dine_in',
    address         TEXT,
    payment_method  ENUM('upi','cash','card') DEFAULT 'cash',
    upi_ref         VARCHAR(100),
    status          ENUM('pending','preparing','ready','delivered','cancelled') DEFAULT 'pending',
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ============================================
-- TABLE: feedback
-- ============================================
CREATE TABLE IF NOT EXISTS feedback (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT,
    name        VARCHAR(100) NOT NULL,
    email       VARCHAR(150),
    rating      TINYINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment     TEXT NOT NULL,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;
