<?php
// includes/header.php - Frontend header
$pageTitle = isset($pageTitle) ? $pageTitle . ' | ' . SITE_NAME : SITE_NAME;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title><?= htmlspecialchars($pageTitle) ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com"/>
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700;900&family=Lato:wght@300;400;700&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css"/>
</head>
<body>
<nav class="navbar" id="navbar">
  <div class="nav-container">
    <a href="<?= SITE_URL ?>" class="nav-logo">Urban <span>Brew</span></a>
    <ul class="nav-links">
      <li><a href="<?= SITE_URL ?>/#about">About</a></li>
      <li><a href="<?= SITE_URL ?>/#menu">Menu</a></li>
      <li><a href="<?= SITE_URL ?>/reserve.php">Reserve</a></li>
      <li><a href="<?= SITE_URL ?>/order.php">Order</a></li>
      <li><a href="<?= SITE_URL ?>/feedback.php">Feedback</a></li>
      <?php if (isset($_SESSION['user_id'])): ?>
        <li><a href="<?= SITE_URL ?>/profile.php">👤 <?= htmlspecialchars($_SESSION['user_name']) ?></a></li>
        <li><a href="<?= SITE_URL ?>/logout.php" class="btn-nav">Logout</a></li>
      <?php else: ?>
        <li><a href="<?= SITE_URL ?>/login.php">Login</a></li>
        <li><a href="<?= SITE_URL ?>/register.php" class="btn-nav">Register</a></li>
      <?php endif; ?>
    </ul>
    <div class="hamburger" id="hamburger"><span></span><span></span><span></span></div>
  </div>
</nav>
<div class="mobile-menu" id="mobileMenu">
  <a href="<?= SITE_URL ?>/#about">About</a>
  <a href="<?= SITE_URL ?>/#menu">Menu</a>
  <a href="<?= SITE_URL ?>/reserve.php">Reserve</a>
  <a href="<?= SITE_URL ?>/order.php">Order</a>
  <a href="<?= SITE_URL ?>/feedback.php">Feedback</a>
  <?php if (isset($_SESSION['user_id'])): ?>
    <a href="<?= SITE_URL ?>/profile.php">👤 <?= htmlspecialchars($_SESSION['user_name']) ?></a>
    <a href="<?= SITE_URL ?>/logout.php">Logout</a>
  <?php else: ?>
    <a href="<?= SITE_URL ?>/login.php">Login</a>
    <a href="<?= SITE_URL ?>/register.php">Register</a>
  <?php endif; ?>
</div>
