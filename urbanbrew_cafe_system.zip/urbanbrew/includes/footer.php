<?php // includes/footer.php ?>
<footer class="site-footer">
  <div class="footer-inner">
    <div class="footer-brand">
      <div class="footer-logo">Urban Brew Cafe</div>
      <p>Crafted with passion, served with soul — Kolhapur's finest since 2015.</p>
    </div>
    <div class="footer-col">
      <h5>Quick Links</h5>
      <a href="<?= SITE_URL ?>/reserve.php">Reserve a Table</a>
      <a href="<?= SITE_URL ?>/order.php">Place an Order</a>
      <a href="<?= SITE_URL ?>/feedback.php">Give Feedback</a>
    </div>
    <div class="footer-col">
      <h5>Contact</h5>
      <a href="tel:8669046436">📞 +91 8669046436</a>
      <a>📍 Station Road, Kolhapur,<br>&nbsp;&nbsp;&nbsp;Maharashtra — 416001</a>
      <a>🕐 Mon–Sun: 7am – 10pm</a>
    </div>
  </div>
  <div class="footer-bottom">
    &copy; <?= date('Y') ?> Urban Brew Cafe. All rights reserved.
  </div>
</footer>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body>
</html>
