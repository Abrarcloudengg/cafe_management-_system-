<?php
require_once 'config.php';
require_once 'includes/auth.php';
if (isLoggedIn()) redirect(SITE_URL . '/profile.php');
$pageTitle = 'Register';
$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $mobile   = trim($_POST['mobile'] ?? '');
    $pass     = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    if (!$name)                           $errors[] = 'Full name is required.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required.';
    if (!preg_match('/^\+?[\d\s\-]{7,15}$/', $mobile)) $errors[] = 'Valid mobile number is required.';
    if (strlen($pass) < 8)               $errors[] = 'Password must be at least 8 characters.';
    if ($pass !== $confirm)              $errors[] = 'Passwords do not match.';

    if (empty($errors)) {
        $db = getDB();
        $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $errors[] = 'Email already registered. Please login.';
        } else {
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $ins = $db->prepare("INSERT INTO users (name, email, mobile, password) VALUES (?,?,?,?)");
            $ins->execute([$name, $email, $mobile, $hash]);
            $success = 'Account created! You can now login.';
        }
    }
}
?>
<?php require_once 'includes/header.php'; ?>
<div class="page-wrap" style="display:flex;align-items:center;justify-content:center;padding:6rem 1.5rem 3rem">
  <div class="form-box" style="width:100%">
    <h2>Create Account</h2>
    <p class="sub">Join Urban Brew and enjoy exclusive offers.</p>
    <?php foreach ($errors as $e): ?><div class="alert alert-error"><?= sanitize($e) ?></div><?php endforeach; ?>
    <?php if ($success): ?><div class="alert alert-success"><?= $success ?> <a href="login.php">Login →</a></div><?php endif; ?>
    <form method="POST" novalidate>
      <div class="form-row">
        <div class="form-group">
          <label>Full Name</label>
          <input type="text" name="name" value="<?= sanitize($_POST['name'] ?? '') ?>" placeholder="Rahul Sharma" required/>
        </div>
        <div class="form-group">
          <label>Mobile Number</label>
          <input type="tel" name="mobile" value="<?= sanitize($_POST['mobile'] ?? '') ?>" placeholder="+91 XXXXX XXXXX" required/>
        </div>
      </div>
      <div class="form-group">
        <label>Email Address</label>
        <input type="email" name="email" value="<?= sanitize($_POST['email'] ?? '') ?>" placeholder="rahul@example.com" required/>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Password</label>
          <input type="password" name="password" placeholder="Min 8 characters" required/>
        </div>
        <div class="form-group">
          <label>Confirm Password</label>
          <input type="password" name="confirm_password" placeholder="Repeat password" required/>
        </div>
      </div>
      <button type="submit" class="submit-btn">Create Account →</button>
    </form>
    <p style="text-align:center;margin-top:1.2rem;font-size:.9rem;color:var(--medium-roast)">
      Already have an account? <a href="login.php" style="color:var(--caramel);font-weight:700">Login →</a>
    </p>
  </div>
</div>
<?php require_once 'includes/footer.php'; ?>
