<?php
require_once 'config.php';
require_once 'includes/auth.php';
$pageTitle = 'Order Online';
$errors = []; $success = '';

$MENU = [
    'Espresso'=>120,'Cappuccino'=>150,'Flat White'=>160,'Caramel Latte'=>180,
    'Matcha Latte'=>190,'Cold Brew'=>170,'Frappuccino'=>220,
    'Butter Croissant'=>110,'Avocado Toast'=>140,'Eggs Benedict'=>190
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = trim($_POST['customer_name'] ?? '');
    $mobile  = trim($_POST['mobile'] ?? '');
    $item    = $_POST['item_name'] ?? '';
    $qty     = intval($_POST['quantity'] ?? 0);
    $type    = $_POST['order_type'] ?? 'dine_in';
    $addr    = trim($_POST['address'] ?? '');
    $pay     = $_POST['payment_method'] ?? 'cash';
    $upiRef  = trim($_POST['upi_ref'] ?? '');

    if (!$name)  $errors[] = 'Name is required.';
    if (!preg_match('/^\+?[\d\s\-]{7,15}$/', $mobile)) $errors[] = 'Valid mobile number required.';
    if (!isset($MENU[$item])) $errors[] = 'Please select a valid menu item.';
    if ($qty < 1 || $qty > 50) $errors[] = 'Quantity must be between 1 and 50.';
    if ($type === 'delivery' && !$addr) $errors[] = 'Delivery address is required.';

    if (empty($errors)) {
        $price   = $MENU[$item];
        $delFee  = ($type === 'delivery') ? 30 : 0;
        $total   = ($price * $qty) + $delFee;
        $db      = getDB();
        $uid     = $_SESSION['user_id'] ?? null;
        $stmt = $db->prepare("INSERT INTO orders (user_id,customer_name,mobile,item_name,quantity,price,total,order_type,address,payment_method,upi_ref) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->execute([$uid,$name,$mobile,$item,$qty,$price,$total,$type,$addr,$pay,$upiRef]);
        $success = "Order placed! $qty × $item = ₹$total. We'll confirm on $mobile shortly.";
    }
}
?>
<?php require_once 'includes/header.php'; ?>
<div class="page-section">
  <div class="container" style="max-width:640px">
    <div class="card" style="margin-top:1rem">
      <h2 style="font-family:'Playfair Display',serif;font-size:1.9rem;font-weight:700;margin-bottom:.3rem">Order Online</h2>
      <p style="color:var(--medium-roast);margin-bottom:1.5rem">Dine In · Takeaway · Home Delivery anywhere in Kolhapur.</p>

      <div class="order-type-wrap">
        <button type="button" class="order-type-btn active" id="btn_dine_in"    onclick="setOrderType('dine_in')">🍽️ Dine In</button>
        <button type="button" class="order-type-btn"        id="btn_takeaway"   onclick="setOrderType('takeaway')">🛍️ Takeaway</button>
        <button type="button" class="order-type-btn"        id="btn_delivery"   onclick="setOrderType('delivery')">🛵 Home Delivery</button>
      </div>

      <?php foreach ($errors as $e): ?><div class="alert alert-error"><?= sanitize($e) ?></div><?php endforeach; ?>
      <?php if ($success): ?><div class="alert alert-success">✅ <?= sanitize($success) ?></div><?php endif; ?>

      <form method="POST" novalidate>
        <input type="hidden" name="order_type" id="ordType" value="dine_in"/>
        <div class="form-row">
          <div class="form-group">
            <label>Customer Name</label>
            <input type="text" name="customer_name" value="<?= sanitize($_POST['customer_name'] ?? '') ?>" placeholder="Your name" required/>
          </div>
          <div class="form-group">
            <label>Mobile Number</label>
            <input type="tel" name="mobile" value="<?= sanitize($_POST['mobile'] ?? '') ?>" placeholder="+91 XXXXX XXXXX" required/>
          </div>
        </div>
        <div class="form-group" id="addrGroup" style="display:none">
          <label>Delivery Address, Kolhapur</label>
          <textarea name="address" placeholder="Flat no, Street, Area, Kolhapur — PIN"><?= sanitize($_POST['address'] ?? '') ?></textarea>
        </div>
        <div id="delNotice" style="display:none;background:#fff8f0;border:1px solid var(--latte);border-radius:10px;padding:.7rem 1rem;margin-bottom:1rem;font-size:.86rem;color:var(--medium-roast)">
          🛵 <strong>Home Delivery charge: ₹30</strong> added for delivery within Kolhapur.
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>Menu Item</label>
            <select name="item_name" id="ordItem" onchange="calcOrderTotal()" required>
              <option value="">Select item</option>
              <?php foreach ($MENU as $name => $price): ?>
                <option value="<?= $name ?>" <?= (($_POST['item_name'] ?? '') === $name) ? 'selected' : '' ?>><?= $name ?> — ₹<?= $price ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label>Quantity</label>
            <input type="number" name="quantity" id="ordQty" min="1" max="50" value="<?= intval($_POST['quantity'] ?? 1) ?>" onchange="calcOrderTotal()" required/>
          </div>
        </div>
        <div class="total-bar">
          <span>Total Amount</span>
          <span id="ordTotal">₹0</span>
        </div>
        <div class="form-group">
          <label>Payment Method</label>
          <div class="pay-methods">
            <label class="pay-opt"><input type="radio" name="payment_method" value="upi" checked onchange="toggleUPI(this)"/> 📱 UPI / QR</label>
            <label class="pay-opt"><input type="radio" name="payment_method" value="cash" onchange="toggleUPI(this)"/> 💵 Cash</label>
            <label class="pay-opt"><input type="radio" name="payment_method" value="card" onchange="toggleUPI(this)"/> 💳 Card</label>
          </div>
        </div>
        <div class="upi-block" id="upiBlock">
          <p style="font-weight:700;margin-bottom:.5rem">📲 Scan & Pay via UPI</p>
          <img src="https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=upi://pay?pa=8669046436@paytm%26pn=UrbanBrewCafe%26cu=INR" alt="UPI QR"/>
          <p style="font-size:.85rem;color:var(--medium-roast);margin-bottom:.3rem">📞 <strong>8669046436</strong> · PhonePe · GPay · Paytm</p>
          <p style="font-size:.8rem;color:var(--caramel);font-weight:700">UPI ID: 8669046436@paytm</p>
        </div>
        <div class="form-group" id="upiRefGroup">
          <label>UPI Transaction ID <span style="font-weight:400;text-transform:none;font-size:.78rem">(after payment)</span></label>
          <input type="text" name="upi_ref" value="<?= sanitize($_POST['upi_ref'] ?? '') ?>" placeholder="e.g. 407812345678"/>
        </div>
        <button type="submit" class="submit-btn">🛒 Place Order →</button>
      </form>
    </div>
  </div>
</div>
<?php require_once 'includes/footer.php'; ?>
